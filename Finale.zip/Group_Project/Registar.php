<?php

// ... (My validation code)

if (strlen($_POST["password"]) < 8) {
    die("Your password must be at least 8 characters long");
}

if (!preg_match("/[0-9]/", $_POST["password"])) {
    die("Your password must contain at least one number");
}

if ($_POST["password"] !== $_POST["Conpassword"]) {
    die("Passwords do not match");
}

$Hash_Password = password_hash($_POST["password"], PASSWORD_DEFAULT);

$mysqli = require __DIR__ . "/Database.php";

$sql = "INSERT INTO useraccount (name, surname, email, homeAddress, IDNum, Hash_Password)
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $mysqli->prepare($sql);

if (!$stmt) {
    die("SQL error: " . $mysqli->error);
}

$stmt->bind_param("ssssss", $_POST["name"],
                            $_POST["Surname"], // "Surname" (case-sensitive)
                            $_POST["email"],   // "Email" (case-sensitive)
                            $_POST["Address"], // "Address" (case-sensitive)
                            $_POST["ID"],      // "ID" (case-sensitive)
                            $Hash_Password);

if (!$stmt->execute()) {
    die("Error executing query: " . $stmt->error);
}

echo "Sign up successful";

$stmt->close();
$mysqli->close();

?>
