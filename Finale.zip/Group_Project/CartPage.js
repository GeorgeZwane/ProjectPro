let cartItems = [];

function addToCart(productId, title, price, image) {
  const item = {
    productId: productId,
    title: title,
    price: price,
    image: image,  // Make sure you have the image URL here
  };
  cartItems.push(item);
  updateCart();
}

function updateCart() {
    if (cartItems.length == 0) {
        document.getElementById('cartItem').innerHTML = 'Your cart is empty';
    } else {
        let cartContent = cartItems.map((item, index) => {
            return `
                <div class="cart-item">
                    <div class="row-image">
                        <img class="rowing" src="${item.image}">
                    </div>
                    <p style="font-size: 13px;">${item.title}</p>
                    <p style="font-size: 10px;">${item.price}</p>
                    <i class="fa-solid fa-trash" onclick="delElement(${index})"></i>
                </div>
            `;
        }).join('');

        document.getElementById('cartItem').innerHTML = cartContent;
    }
}

document.addEventListener("DOMContentLoaded", function () {
    // Get the minus and plus buttons by their IDs
    const minusBtn = document.getElementById("minus-btn-1");
    const plusBtn = document.getElementById("plus-btn-1");
    
    // Get the quantity display element
    const quantityDisplay = document.getElementById("quantity-1");
  
    // Add event listener for minus button
    minusBtn.addEventListener("click", function () {
      const currentQty = parseInt(minusBtn.getAttribute("data-qty"));
      if (currentQty > 0) {
        minusBtn.setAttribute("data-qty", currentQty - 1);
        quantityDisplay.textContent = currentQty - 1;
      }
    });
  
    // Add event listener for plus button
    plusBtn.addEventListener("click", function () {
      const currentQty = parseInt(plusBtn.getAttribute("data-qty"));
      plusBtn.setAttribute("data-qty", currentQty + 1);
      quantityDisplay.textContent = currentQty + 1;
    });
  });
  
