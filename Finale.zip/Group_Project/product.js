let preveiwContainer = document.querySelector('.products-preview');
let previewBox = preveiwContainer.querySelectorAll('.preview');

document.querySelectorAll('.row .content').forEach(content =>{
  content.onclick = () =>{
    preveiwContainer.style.display = 'flex';
    let name = content.getAttribute('data-name');
    previewBox.forEach(preview =>{
      let target = preview.getAttribute('data-target');
      if(name == target){
        preview.classList.add('active');
      }
    });
  };
});

previewBox.forEach(close =>{
  close.querySelector('.fa-times').onclick = () =>{
    close.classList.remove('active');
    preveiwContainer.style.display = 'none';
  };
});


const cartIcon = document.querySelector(".cart-icon");
const cartContainer = document.querySelector(".cart-container");
const cartItems = document.querySelector(".cart-items");
const cartTotal = document.querySelector(".cart-total");

let itemCount = 0;
let totalAmount = 0;

cartIcon.addEventListener("click", () => {
    cartContainer.classList.toggle("open");
});

function addToCart(itemName, itemPrice) {
    itemCount++;
    totalAmount += itemPrice;
    cartCount.textContent = itemCount;
    
    const cartItem = document.createElement("li");
    cartItem.textContent = `${itemName} - $${itemPrice.toFixed(2)}`;
    cartItems.appendChild(cartItem);
    
    cartTotal.textContent = `Total: $${totalAmount.toFixed(2)}`;
}
